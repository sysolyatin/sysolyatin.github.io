-- ------------------------------------------------------------------
-- Плагин для создания экзекьютора с диммерными эффектами для группы
-- Версия 1.0                                  Дата выхода 26.05.2023
-- ------------------------------------------------------------------
--
-- Использование:
-- Необходимо запустить плагин, указать для какой группы создавать
-- эффекты, указать номер экзекьютора, куда нужно их записать и 
-- ввести имя для этого экзекьютора.
--
-- Плагин поставляется КАК ЕСТЬ! Я не отвечаю за его работу, за любые
-- неполадки, которые могут возникнуть в вашем шоу при работе с этим
-- плагином. Но всегда по возможности готов помочь и исправить баги.
--
-- Артем Сысолятин (с) 2023
-- Сделано в России


function getLabel (ma2Name)
  local handle = gma.show.getobj.handle(ma2Name)
  local label = gma.show.getobj.label(handle)
  if label==nil then label='LabelErr' end
  return label
end

function getIndex (ma2Name)
  local handle = gma.show.getobj.handle(ma2Name)
  local index = gma.show.getobj.index(handle)
  return index
end

function Start()
    ::AGAIN::
        local groupId = tonumber(gma.textinput('Group number for create DimFX', '1'));
        local dimFxExecNumber = tonumber(gma.textinput('Dim FX Exec number', '21'));
        local dimFxLabel = gma.textinput('Dim FX label', getLabel('Group '..groupId)..' FX');

        if groupId == nil then    
            groupMsg = ('Groups pool is empty!')
            goto AGAIN
        end    
        
        local check = getIndex('Group '..groupId)
        if check==nil then 
            groupMsg=('Group '..groupId..' does not exist')
            goto AGAIN                             
        end 

        if ((groupId==nil) or (dimFxExecNumber==nil) or (dimFxLabel==nil)) then 
            goto AGAIN 
        end

    createEffects(groupId, dimFxExecNumber, dimFxLabel);

end


function createEffects(groupId, fxExecNumber, execLabel)
    createDimFx(groupId, 8, "0 thru -360", "S >", 1, fxExecNumber);
    createDimFx(groupId, 8, "0 thru 360", "S <", 2, fxExecNumber);
    createDimFx(groupId, 8, "360 Thru 0 Thru 360", "S ><", 3, fxExecNumber);
    createDimFx(groupId, 8, "0 Thru 360 Thru 0", "S <>", 4, fxExecNumber);
    createDimFx(groupId, 4, "0 thru -360", "P >", 5, fxExecNumber);
    createDimFx(groupId, 4, "0 thru 360", "P <", 6, fxExecNumber);
    createDimFx(groupId, 4, "360 Thru 0 Thru 360", "P ><", 7, fxExecNumber);
    createDimFx(groupId, 4, "0 Thru 360 Thru 0", "P <>", 8, fxExecNumber);

    gma.cmd("Assign Learn ExecButton1 "..fxExecNumber);
    gma.cmd("Assign >>> ExecButton2 "..fxExecNumber);
    gma.cmd("Assign <<< ExecButton3 "..fxExecNumber);
    gma.cmd("Assign Executor "..fxExecNumber.." /autostart=on /autostop=off /priority=6 /ooo=off");
    gma.cmd('Label Executor '..fxExecNumber..' "'..execLabel..'"');
    gma.cmd('Assign Sequence "'..execLabel..'" /track=off')
    gma.cmd('ClearAll');

end

function createDimFx(groupId, form, phase, label, cue, execNumber)
    gma.cmd('ClearAll');
    gma.cmd('Group '..groupId);
    gma.cmd('Attribute "dim" At EffectForm '..form);
    gma.cmd('Attribute "dim" At EffectBPM 30');
    gma.cmd('Attribute "dim" At EffectPhase '..phase);
    if form==4 then 
        gma.cmd('Attribute "dim" At EffectWidth 35');
        gma.cmd('Attribute "dim" At EffectDecay 10');
    end
    gma.cmd('Store Cue '..cue..' exec '..execNumber..' /o /nc /name="'..label..'"');
    gma.cmd('Assign Cue '..cue..' exec '..execNumber..' /name="'..label..'"');
    gma.cmd('Exec '..execNumber..' at 0');
    gma.cmd('ClearAll');
end


return Start;