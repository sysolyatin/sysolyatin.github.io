function Start()
    ::AGAIN::

        local fixtireId = tonumber(gma.textinput('Blinder first FixID', '1'));
        local blindersCount = tonumber(gma.textinput('Blinder fixture count', '8'));
        local coldGroup = tonumber(gma.textinput('Group number for cold', '3'));
        local warmGroup = tonumber(gma.textinput('Group number for warm', '4'));
        local fxNumber = tonumber(gma.textinput('Start FX number (you need at least 9 free cells in a row)', '1'));
        local buhExec = tonumber(gma.textinput('BUHHH exec number', '105'));
        local strobeExecNumber = tonumber(gma.textinput('White strobe exec number', '106'));
        local dimFxExecNumber = tonumber(gma.textinput('Dim FX exec number', '24'));

        if ((fixtireId==nil) or (blindersCount==nil) or (coldGroup==nil) or (warmGroup==nil) or (fxNumber==nil) or (strobeExecNumber==nil) or (dimFxExecNumber==nil) or (buhExec==nil)) then 
            goto AGAIN 
        end

    local i = 1
    while true do
        if (i > blindersCount) then
            goto AFTER_CREATE_GROUPS
        end
        gma.cmd('ClearAll');
        gma.cmd('Fixture '..fixtireId..'.2');
        gma.cmd('Store Group '..coldGroup..'/m /nc');
        gma.cmd('ClearAll');
        gma.cmd('Fixture '..fixtireId..'.1');
        gma.cmd('Store Group '..coldGroup..'/m /nc');
        gma.cmd('ClearAll');
        gma.cmd('Fixture '..fixtireId..'.4');
        gma.cmd('Store Group '..warmGroup..'/m /nc');
        gma.cmd('ClearAll');
        gma.cmd('Fixture '..fixtireId..'.3');
        gma.cmd('Store Group '..warmGroup..'/m /nc');
        gma.cmd('ClearAll');
        i=i+1;
        fixtireId=fixtireId+1;
    end

    ::AFTER_CREATE_GROUPS::


    gma.cmd('Label Group '..coldGroup..' "Cold Blinders"');
    gma.cmd('Label Group '..warmGroup..' "Warm Blinders"');

    createColdStrobe(coldGroup, fxNumber, strobeExecNumber);
    fxNumber=fxNumber+1;

    createEffects(warmGroup, fxNumber, dimFxExecNumber);
    createBuhhh(warmGroup, buhExec);

end


function createColdStrobe(groupId, strFxNumber, strExecNumber)
    gma.cmd('ClearAll');
    gma.cmd("Group "..groupId);
    gma.cmd("EffectForm 4");
    gma.cmd("EffectBPM 450");
    gma.cmd("EffectPhase 0");
    gma.cmd("Store Effect "..strFxNumber.." /o /nc");
    gma.cmd('ClearAll');
    gma.cmd('Label Effect '..strFxNumber..' "COLD SWOP STROBE"');
    gma.cmd('Appearance Effect '..strFxNumber..' /red=100 /green=0 /blue=0');
    gma.cmd("Group "..groupId.." At Effect "..strFxNumber);
    gma.cmd('Store Exec '..strExecNumber..' /o /nc');
    gma.cmd('Assign Swop Exec '..strExecNumber);
    gma.cmd('Appearance Exec '..strExecNumber..' /red=100 /green=0 /blue=0');
    gma.cmd('Label Exec '..strExecNumber..' "SWOP STROBE"');
    gma.cmd('ClearAll');
end

function createEffects(groupId, dimFxNumber, dimExecNumber)
    gma.cmd("Select "..dimExecNumber);

    createDimFx(groupId, dimFxNumber, 8, ">", 0, "sin >", 1);
    createDimFx(groupId, dimFxNumber+1, 8, "<", 0, "sin <", 2);
    createDimFx(groupId, dimFxNumber+2, 8, ">", 2, "sin ><", 3);
    createDimFx(groupId, dimFxNumber+3, 8, "<", 2, "sin <>", 4);
    createDimFx(groupId, dimFxNumber+4, 4, ">", 0, "pwm >", 5);
    createDimFx(groupId, dimFxNumber+5, 4, "<", 0, "pwm <", 6);
    createDimFx(groupId, dimFxNumber+6, 4, ">", 2, "pwm ><", 7);
    createDimFx(groupId, dimFxNumber+7, 4, "<", 2, "pwm <>", 8);

    gma.cmd("Assign Learn ExecButton1 "..dimExecNumber);
    gma.cmd("Assign >>> ExecButton2 "..dimExecNumber);
    gma.cmd("Assign <<< ExecButton3 "..dimExecNumber);
    gma.cmd("Assign Executor "..dimExecNumber.." /autostart=on /autostop=off /priority=6 /ooo=off");
    gma.cmd('Label Executor '..dimExecNumber..' "BLINDER DIM FX"');
    gma.cmd('Assign Sequence "BLINDER DIM FX" /track=off')
    gma.cmd('ClearAll');

end

function createDimFx(groupId, dimFxNumber, form, dir, wings, label, cue)
    gma.cmd('ClearAll');
    gma.cmd("Group "..groupId);
    gma.cmd("EffectForm "..form);
    gma.cmd("EffectBPM 30");
    gma.cmd("Store Effect "..dimFxNumber.." /o /nc");
    gma.cmd("Assign Effect "..dimFxNumber.." /phase=0..-360 /dir="..dir.." /wings="..wings)
    gma.cmd('ClearAll');
    gma.cmd('Label Effect '..dimFxNumber..' "blinders '..label..'"');

    gma.cmd("Group "..groupId.." At Effect "..dimFxNumber);
    gma.cmd('Store Cue '..cue..' /o /nc /name="'..label..'"');
    gma.cmd('Assign Cue '..cue..' /name="'..label..'"');
    gma.cmd('ClearAll');
end

function createBuhhh(groupId, buhExecNumber)
    gma.cmd('ClearAll');
    gma.cmd("Group "..groupId.." At 100");
    gma.cmd('Store Executor '..buhExecNumber);
    gma.cmd('Label Executor '..buhExecNumber..' "BUHH"');
    gma.cmd("Assign Temp ExecButton1 "..buhExecNumber);
    gma.cmd("Assign Executor "..buhExecNumber.." /OffTime=0.8");
    gma.cmd('ClearAll');
end

return Start;